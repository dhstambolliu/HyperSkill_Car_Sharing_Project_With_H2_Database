create
    definer = root@localhost procedure GetOrderAmount(IN pOrderNumber int)
BEGIN
SELECT
		SUM(quantityOrdered * priceEach)
					    FROM orderDetails
					    WHERE orderNumber = pOrderNumber;
					END;

